# Description: This file contains the functions to format the content of the CVs

# Fix New line and backtick formatting
def format_backtick(text):
    # Replace \\n formatting with double space \n. Added for claude model
    if isinstance(text, str):
        text = text.strip("'\"")
        lines = text.replace("\\n", "\n").split("\n")
        text = "  \n".join(lines)
    text = str(text).replace(r"(^|[^`])`([^`]+)`([^`]|$)", r"\1**\2**\3")
    return text