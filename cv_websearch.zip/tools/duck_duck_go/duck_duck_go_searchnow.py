from langchain_community.tools import DuckDuckGoSearchRun, DuckDuckGoSearchResults
from langchain.agents import tool
from langchain_community.utilities import DuckDuckGoSearchAPIWrapper


@tool
def duck_duck_go_search_now(query: str):
    """Search for words, documents, images, videos, news, maps and text translation using the DuckDuckGo.com search engine."""

    # search = DuckDuckGoSearchRun()
    wrapper = DuckDuckGoSearchAPIWrapper(region="in-en", time="none", max_results=3, safesearch="strict")
    search = DuckDuckGoSearchResults(api_wrapper=wrapper)
    results = search.run(query)
    return results
