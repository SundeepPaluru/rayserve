import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain.agents import create_react_agent, AgentExecutor
from templates.ReAct_template import get_react_prompt_template
from tools.time_calc.time_calc import check_system_time
from tools.duck_duck_go.duck_duck_go_searchnow import duck_duck_go_search_now
from langchain_core.output_parsers import MarkdownListOutputParser
from langchain.memory import ConversationBufferMemory
from cv_libray.formatContent import format_backtick

# : Import ray serve and request from starlette
import ray
from ray import serve
from starlette.requests import Request
from fastapi import FastAPI
app = FastAPI()


@serve.deployment(num_replicas=1, ray_actor_options={"num_cpus": 1, "num_gpus": 0})
@serve.ingress(app)
class deployllm:
    def __init__(self):
        load_dotenv()
        self.llm = AzureChatOpenAI(
            openai_api_version=os.environ["OPENAI_API_VERSION"],
            azure_deployment=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"],
        )
        self.memory = ConversationBufferMemory(memory_key="chat-history", return_messages=True)
        self.tools = [check_system_time, duck_duck_go_search_now]
        self.agent = create_react_agent(self.llm, self.tools, get_react_prompt_template())
        self.agent_executor = AgentExecutor(agent=self.agent, tools=self.tools, verbose=True,
                                            handle_parsing_errors=True, max_iterations=3)

    @app.post("/")
    def query(self, query: str):
        # query = await request.body()
        results = self.agent_executor.invoke({"input": query})
        return results


# Bind the model to deployment
cv_websearch = deployllm.bind()
